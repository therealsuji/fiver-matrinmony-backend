<?php

namespace App\Model;

use  \CodeIgniter\Model;
use Config\Database;

class  UserPhysicalDetailsModel extends Model
{
//    public function __construct(\CodeIgniter\Database\ConnectionInterface &$db = null, \CodeIgniter\Validation\ValidationInterface $validation = null)
//    {
//
//        $this->createTable();
//        parent::__construct($db, $validation);
//    }

    protected $table = 'user_physical_details';
    protected $primaryKey = 'user_id';

    protected $allowedFields = [
        'user_id',
        'height',
        'weight',
        'complexion',
        'blood_group',
        'body_type',
        'disability',
    ];

    protected $useTimestamps = false;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';


    public function createTable()
    {
        $forge = Database::forge();
        if ($forge) {
            $fields = [

                'user_id' => [
                    'type' => 'INT',
                    'constraint' => 5,
                    'unsigned' => true,
                    'unique' => true,
                ],
                'height' => [
                    'type' => 'INT',
                    'constraint' => '5',
                ],
                'weight' => [
                    'type' => 'INT',
                    'constraint' => '5',
                ],
                 'complexion' => [
                    'type' => 'INT',
                    'constraint' => '5',
                ],
                'blood_group' => [
                    'type' => 'INT',
                    'constraint' => '5',
                ],
                'body_type' => [
                    'type' => 'INT',
                    'constraint' => '5',
                ],
                'disability' => [
                    'type' => 'VARCHAR',
                    'constraint' => '100',
                ],
                'created_at datetime default current_timestamp',
                'updated_at datetime default current_timestamp on update current_timestamp',
            ];
            $forge->addField($fields)->createTable('user_physical_details', true);
        }
    }


}