<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Matrimony </title>
    <link rel="icon" href="<?= base_url('favicon.ico')?>" type="image/ico" sizes="16x16">
    <link href="<?= base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet"  >
    <link href="<?= base_url('assets/css/index.css')?>" rel="stylesheet" >
</head>
<body>



