<div class="container margin-container">
    <div class="col-md-12">
        <div class="stat">
            <label for="">User Count</label>
            <div><?= $userCount ?></div>
        </div>
        <div class="stat">
            <label for="">Female User Count</label>
            <div><?= $femaleUserCount ?></div>
        </div>
        <div class="stat">
            <label for="">Male User Count</label>
            <div><?= $maleUserCount ?></div>
        </div>
    </div>
</div>